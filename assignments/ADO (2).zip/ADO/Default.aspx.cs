﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    // Make sure you understand why these properties are static
    private static System.Data.SqlClient.SqlConnection conn;
    private static SqlCommand comm;
    private static SqlDataReader reader;

    /**
     *  Page Load event handler
     * 
     */
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // We will open the connection one time and leave it open.
            OpenConnection();           
        }
    }

    /**
     * Open the connection to the database
     */ 
    private void OpenConnection()
    {
        System.Configuration.ConnectionStringSettings strConn;
        strConn = ReadConnectionString();
        // Console.WriteLine(strConn.ConnectionString);

        conn = new System.Data.SqlClient.SqlConnection(strConn.ConnectionString);

        // This could go wrong in so many ways...
        conn.Open();
    }   

    /**
     * Load some data from the databse into a text box
     */
    private void LoadTextBox()
    {
        String tmp;

//      If we get here, the connection attempt worked.
//      Note that the connection becomes part of the SQL command in the following statement:
        comm = new SqlCommand("SELECT Fish FROM tFish ORDER BY Fish", conn);

        // This could also fail
        try { reader.Close(); }
        catch (Exception ex) { }
        reader = comm.ExecuteReader();      // Se also ExecuteScalar and ExecuteNonQuery

        // Now we have our data in the reader object
        lblTest.Text = "";
        if (reader.HasRows) {       // probably don't need this. 
            while (reader.Read())
            {
                tmp = reader.GetString(0);      // Column 0 in the results set. Refer back to the construction of the query.
                System.Console.WriteLine(tmp);
                lblTest.Text += tmp + "<br>";
            }
        }

        // Run the query again. It's forward-scrolling only so we can't reread it. Can you think of a better way?
        reader.Close();

        // You can leave it open if you're judicious about it.
        //conn.Close();
    }


      /** Read the connection string from the web.config file. 
      * This is a much more secure way to store sensitive information. Don't hard-code connection information in the source code.
      * Adapted from http://msdn.microsoft.com/en-us/library/ms178411.aspx
      */
    private System.Configuration.ConnectionStringSettings ReadConnectionString()
    {
        String strPath;
        strPath = HttpContext.Current.Request.ApplicationPath + "/web.config";
        System.Configuration.Configuration rootWebConfig =
            System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration(strPath);

        System.Configuration.ConnectionStringSettings connString = null;
        if (rootWebConfig.ConnectionStrings.ConnectionStrings.Count > 0)
        {
            connString = rootWebConfig.ConnectionStrings.ConnectionStrings["IT3037CConnectionString"];
/*
            if (connString != null)
                Console.WriteLine("Northwind connection string = \"{0}\"",
                    connString.ConnectionString);
            else
                Console.WriteLine("No Northwind connection string");
*/
        }
        return connString;
    }
    /**
     * Load some data from the database into a list box
     */
    private void LoadListBox()
    {
        String tmp;
        int tmpID;
        ListItem myListItem;

        // Clear the list box, in case we've already loaded something into it.
        lbFish.Items.Clear();
        comm = new SqlCommand("SELECT FishID, Fish FROM tFish ORDER BY Fish", conn);
        try {reader.Close();} catch(Exception ex) {}
        reader = comm.ExecuteReader();
 
        while (reader.Read())
        {
            tmpID = reader.GetInt32(0);    // Column 1 in the results set. Refer back to the construction of the query.
            tmp = reader.GetString(1);      // Column 0 in the results set. Refer back to the construction of the query.
            //System.Console.WriteLine(tmp);
            //lbFish.Items.Add(tmp);
            myListItem = new ListItem(tmp, Convert.ToString(tmpID));
            lbFish.Items.Add(myListItem);
        }
    }

    /**
     * Click event handler for the Go Button. This demonstrates how to access the "selected" information in the list box
     */
    protected void btnGo_Click(object sender, EventArgs e)
    {
          lblSelection.Text = "You selected " + lbFish.SelectedItem + " (" + lbFish.SelectedValue + ")";
    }
    /**
     *  Click event handler for LoadTextBox button
     * 
     */
    protected void btnLoadTextBox_Click(object sender, EventArgs e)
    {
        LoadTextBox();
    }

    /**
     *  Click event handler for LoadListBox button
     * 
     */
    protected void btnLoadListBox_Click(object sender, EventArgs e)
    {
        LoadListBox();
    }
    }